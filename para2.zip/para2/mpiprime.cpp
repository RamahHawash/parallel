#include <iostream>
#include<mpi.h>
#include <sys/time.h>
#include<cmath>
using namespace std;

double GetWallTime() {
struct timeval tp;
int rtn = gettimeofday(&tp, NULL);
return ((double) tp.tv_sec + (1.e-6)*tp.tv_usec);
}
bool isprime ( long n ){
int j;
for ( j=2 ;j<sqrt(n);j++)
if(n%j==0)return false;
if(n%j != 0) return true;
return 0;
}//prime
int main(int argc,char **argv){


int comm_sz;
int my_rank;
int *a=NULL;
int *b=NULL;
a =new int [1000];
b= new int[1000];
long n=0;
int count=0;
int flag=0;
  MPI_Init(&argc,&argv);
  MPI_Comm_size(MPI_COMM_WORLD,&comm_sz);
  MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);


if(my_rank==0){
cout<<"enter the number"<<endl;
  scanf("%ld",&n);
  for(int i=0;i<n-1;i++)
  {
  a[i]=i+2;
  count++;
  }//for

}//mat rank 0
  MPI_Scatter(a, (n-1)/comm_sz, MPI_INT,b,(n-1)/comm_sz, MPI_INT, 0, MPI_COMM_WORLD);
for(int i=0;i<comm_sz;i++){
cout<<i<<":"<<endl;
if(i==0)cout<<2<<endl;
for(int j=0;j<=((n-1)/comm_sz);j++)
  {

  if(isprime(a[j])==1)cout<<a[j]<<endl;
  }//for

}//for

double start = GetWallTime();

double finish = GetWallTime();
cout << "Elapsed time = "<< finish - start << endl;

  MPI_Finalize();
  return 0;


}
