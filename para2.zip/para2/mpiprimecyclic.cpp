#include <iostream>
#include <mpi.h>
#include <cmath>
#include <sys/time.h>
using namespace std;
double GetWallTime() {
struct timeval tp;
int rtn = gettimeofday(&tp, NULL);
return ((double) tp.tv_sec + (1.e-6)*tp.tv_usec);
}
bool isprime ( long n ){
int j;
for ( j=2 ;j<sqrt(n);j++)
if(n%j==0)return false;
if(n%j != 0) return true;
return 0;
}//prime
int main(int argc,char **argv){


int flag=0;
int comm_sz;
long n;
int *a= new int[90];
  int my_rank;
  int count =0;
  MPI_Init(&argc,&argv);
  MPI_Comm_size(MPI_COMM_WORLD,&comm_sz);
  MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);
  if(my_rank ==0){
  cout<<"enater a number"<<endl;
  scanf("%ld",&n);
  int flag=0;
    for(int i=0;i<n-1;i++)
  {
  a[i]=i+2;
  count++;
  }//for
  MPI_Bcast(a, count, MPI_INT, 0, MPI_COMM_WORLD);
  if(my_rank==0){
cout<<my_rank<<":"<<endl;
cout<<2<<endl;
for(int i=3;i<=(n-1)/comm_sz;i++)
  {
  if(isprime(i)==1)cout<<i<<endl;
  }//for

}


double start = GetWallTime();
// Code to be timed /
double finish = GetWallTime();
cout << "Elapsed time = "<< finish - start << endl;
  MPI_Finalize();
  return 0;
  
}//main
}
