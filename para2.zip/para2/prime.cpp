#include <iostream>
#include <cmath>
#include <mpi.h>
using namespace std;

bool isprime ( long n ){
int j;
for ( j=2 ;j<sqrt(n);j++)
if(n%j==0)return false;
if(n%j != 0) return true;
return 0;
}//prime
int main(int argc,char **argv){
long a;
int comm_sz;
  int my_rank;
  MPI_Init(&argc,&argv);
  MPI_Comm_size(MPI_COMM_WORLD,&comm_sz);
  MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);
      if(my_rank ==0){
  cout<<"enater a number"<<endl;
  scanf("%ld",&a);
  cout<<"the prime numbers"<<endl;
  cout<<2<<endl;
  for(int i=3;i<=a;i++)
  {
  if(isprime(i)==1)cout<<i<<endl;
  }//for

  }//rank0;
  MPI_Finalize();
  return 0;

}//main
