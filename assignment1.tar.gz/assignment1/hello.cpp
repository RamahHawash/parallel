#include <stdio.h>
#include <string.h>
#include <iostream>
#include <mpi.h>

using namespace std;
const int MAX_STRING=100;

int main(void){
  
  char greeting[MAX_STRING];
  int comm_sz;
  int my_rank;
  int len=0;
	char *name =  new char[MPI_MAX_PROCESSOR_NAME];
int  a;
  //char name[MPI_MAX_PROCESSOR_NAME];
  MPI_Init(NULL,NULL);
 
  MPI_Comm_size(MPI_COMM_WORLD,&comm_sz);
  MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);
  MPI_Get_processor_name(name,&len);

    if(my_rank ==0){
      cout<<"enter a number"<<endl;
scanf("%d",&a);
	MPI_Send(&a,1,MPI_INT,my_rank+1,0,MPI_COMM_WORLD);
	MPI_Recv(&a,1,MPI_INT,comm_sz-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
	  	  cout<<a<<endl;
  }//0
  else {
  
  if(my_rank%2!=0){
  	MPI_Recv(&a,1,MPI_INT,my_rank-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);

  	a=a*2;
  	if(my_rank!=comm_sz-1){MPI_Send(&a,1,MPI_INT,my_rank+1,0,MPI_COMM_WORLD);}//if

  	}//if off
  	else if(my_rank%3==0&&my_rank%2==0){
  	  	MPI_Recv(&a,1,MPI_INT,my_rank-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
  	  	a=a*3;
  	  		if(my_rank!=comm_sz-1){MPI_Send(&a,1,MPI_INT,my_rank+1,0,MPI_COMM_WORLD);}
  	}//else if
  	else {
  	  	  	MPI_Recv(&a,1,MPI_INT,my_rank-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
  	  	  	a=a+my_rank;
  	  	  	  	if(my_rank!=comm_sz-1) {MPI_Send(&a,1,MPI_INT,my_rank+1,0,MPI_COMM_WORLD);}
  	}//else
  	if(my_rank==comm_sz-1){ MPI_Send(&a,1,MPI_INT,0,0,MPI_COMM_WORLD);}//else	
  	
  
  }//else
  
  if(my_rank !=0){
  cout<<"hi"<<endl;
  
    sprintf(greeting,"hello world from process %d of %d and the name is %s ",my_rank,comm_sz,name);
        MPI_Send(greeting,strlen(greeting)+1,MPI_CHAR,0,0,MPI_COMM_WORLD);
        \
    if(my_rank%2==0){
    cout<<"hello from "<<my_rank<<endl;
    }
  else {
    cout<<"hi from "<<my_rank<<endl;
    }

    }//if

  else {
  cout<<"hello"<<endl;
  
    printf("hello world from process %d of %d and the name is %s\n",my_rank,comm_sz,name);
    cout<<"hello from "<<my_rank<<endl;
    for(int q=1;q<comm_sz;q++){
      MPI_Recv(greeting,MAX_STRING,MPI_CHAR,q,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
      printf("%s\n",greeting);
   
    }//for
    
  }//else
  
//printf("%d",a);
  MPI_Finalize();
  return 0;
}
  
